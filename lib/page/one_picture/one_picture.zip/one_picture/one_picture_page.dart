import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kayo_package/kayo_package.dart';
import 'package:omt/bean/one_picture/one_picture/one_picture_data_entity.dart';
import 'one_picture_view_model.dart';
import 'package:graphview/GraphView.dart';

///
///  omt
///  one_picture_page.dart
///  一张图
///
///  Created by kayoxu on 2024-12-03 at 10:09:44
///  Copyright © 2024 .. All rights reserved.
///

class OnePicturePage extends StatelessWidget {
  const OnePicturePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ProviderWidget<OnePictureViewModel>(
        model: OnePictureViewModel(),
        autoLoadData: true,
        builder: (context, model, child) {
          return ToolBar(
            title: '一张图',
            elevation: 0,
            actions: [
              TextButton(
                  onPressed: () {
                    model.refresh();
                  },
                  child: Text('刷新'))
            ],
            iosBack: true,
            child: InteractiveViewer(
                constrained: false,
                boundaryMargin: EdgeInsets.all(100),
                minScale: 0.01,
                maxScale: 5.6,
                child: model.graph.nodeCount() == 0
                    ? Container()
                    : GraphView(
                        graph: model.graph,
                        algorithm: SugiyamaAlgorithm(model.builder),
                        paint: Paint()
                          ..color = Colors.green
                          ..strokeWidth = 1
                          ..style = PaintingStyle.stroke,
                        builder: (Node node) {
                          var a = node.key!.value as String?;
                          return rectangleWidget(model, a);
                        },
                      )),
          );
        });
  }

  Widget rectangleWidget(OnePictureViewModel model, String? nodeId) {
    OnePictureDataData? onePictureDataData = model.dataMap[nodeId];

    if ((onePictureDataData?.getChildList() ?? []).isNotEmpty) {
      return Container(
        child: Column(
          children: [
            TextView(onePictureDataData?.name),
            Container(
              padding:
                  EdgeInsets.only(top: 16, bottom: 16, left: 16, right: 16),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey, width: 1),
                  borderRadius: BorderRadius.circular(4)),
              child: Row(
                children: onePictureDataData!.getChildList().map((e) {
                  return rectangleSubWidget(model, '${e.type}_${e.id}');
                }).toList(),
              ),
            )
          ],
        ),
      );
    }

    return GestureDetector(
        onTap: () {
          print('tapped' + '${onePictureDataData?.name}');
        },
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              boxShadow: [
                BoxShadow(color: Colors.blue[100]!, spreadRadius: 1),
              ],
            ),
            child: Text('${onePictureDataData?.name}')));
  }

  Widget rectangleSubWidget(OnePictureViewModel model, String? nodeId) {
    OnePictureDataData? onePictureDataData = model.dataMap[nodeId];
    final Graph graph = Graph();
    SugiyamaConfiguration builder = SugiyamaConfiguration()
      ..bendPointShape = CurvedBendPointShape(curveLength: 6)
      ..coordinateAssignment = CoordinateAssignment.UpRight;

    bool addNewGraph = false;

    if ((onePictureDataData?.nextList ?? []).isNotEmpty) {
      addNewGraph = true;
      model.doSetDataToGraph(graph, onePictureDataData);

      builder
        ..nodeSeparation = (100)
        ..levelSeparation = (100)
        ..orientation = SugiyamaConfiguration.ORIENTATION_TOP_BOTTOM
        ..coordinateAssignment = CoordinateAssignment.UpRight;
    }

    Widget cW = const SizedBox.shrink();

    if ((onePictureDataData?.getChildList() ?? []).isNotEmpty) {
      cW = Row(
        children: onePictureDataData!.getChildList().map((e) {
          return rectangleSubWidget(model, '${e.type}_${e.id}');
        }).toList(),
      );
    }

    if (addNewGraph) {
      return GraphView(
        graph: graph,
        algorithm: SugiyamaAlgorithm(builder),
        paint: Paint()
          ..color = Colors.green
          ..strokeWidth = 1
          ..style = PaintingStyle.stroke,
        builder: (Node node) {
          // I can decide what widget should be shown here based on the id
          var nodeId = node.key!.value as String?;
          return rectangleSubWidget(model, nodeId);
        },
      );
    }

    return GestureDetector(
        onTap: () {
          print('tapped' + '${onePictureDataData?.name}');
        },
        child: Container(
            padding: EdgeInsets.all(16),
            margin: EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              boxShadow: [
                BoxShadow(color: Colors.blue[100]!, spreadRadius: 1),
              ],
            ),
            child: Column(
              children: [Text('${onePictureDataData?.typeText}'), cW],
            )));
  }
}
